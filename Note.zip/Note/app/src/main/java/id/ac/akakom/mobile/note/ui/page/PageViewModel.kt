package id.ac.akakom.mobile.note.ui.page

import android.arch.lifecycle.ViewModel;

class PageViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
