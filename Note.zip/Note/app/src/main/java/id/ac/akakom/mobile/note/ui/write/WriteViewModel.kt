package id.ac.akakom.mobile.note.ui.write

import android.arch.lifecycle.ViewModel;

class WriteViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
