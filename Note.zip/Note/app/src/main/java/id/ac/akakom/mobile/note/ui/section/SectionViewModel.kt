package id.ac.akakom.mobile.note.ui.section

import android.arch.lifecycle.ViewModel

class SectionViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
